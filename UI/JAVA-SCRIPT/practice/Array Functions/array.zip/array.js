
let arrayFunction = () => {
    let array_one = [1, 2, 3, 4, 5];
    let array_two = ["Hi", "Hello"];

    array = array_one.concat(array_two);
    
    array.reverse();

    console.log(array);
}

arrayFunction();