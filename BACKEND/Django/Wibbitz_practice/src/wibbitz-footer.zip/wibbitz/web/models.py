from django.db import models


class Subscribe(models.Model):
    email = models.EmailField()

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.email


class Customer(models.Model):
    image = models.FileField(upload_to="customers/")

    class Meta:
        ordering = ["id"]
        db_table = "web_Customers"
        verbose_name = "Customer"

    def __str__(self):
        return str(self.image)


class Feature(models.Model):
    image = models.ImageField(upload_to="features/")
    icon = models.FileField(upload_to="features/icons/")
    icon_background = models.CharField(max_length=100)
    title = models.CharField(max_length=255)
    description = models.TextField()
    testimonial_des = models.TextField()
    testimonial_author = models.CharField(max_length=255)
    author_designation = models.CharField(max_length=255)
    testimonial_logo = models.FileField(
        upload_to="features/testimonial_logos/")

    class Meta:
        ordering = ["id"]
        db_table = "web_Features"

    def __str__(self):
        return str(self.image)


class VideoBlog(models.Model):
    image = models.ImageField(upload_to="videoBlogs/images/")
    title = models.CharField(max_length=255)
    logo = models.FileField(upload_to="videoBlogs/logos/")

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return str(self.image)


class Testimonial(models.Model):
    image = models.ImageField(upload_to="testimonial/images/")
    logo = models.FileField(
        upload_to="testimonial/logos/", blank=True, null=True)
    description = models.TextField()
    name = models.CharField(max_length=128)
    designation = models.CharField(max_length=128)
    company_name = models.CharField(max_length=128)
    is_featured = models.BooleanField(default=False)

    class Meta:
        ordering = ["id"]
        db_table = "web_Testimonial"

    def __str__(self):
        return self.name


class MarketingFeature(models.Model):
    image = models.FileField(upload_to="marketing/")
    title = models.CharField(max_length=128)
    description = models.TextField()

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.title


class Product(models.Model):
    image = models.ImageField(upload_to="products/images/")
    title = models.CharField(max_length=128)
    description = models.TextField()
    logo = models.FileField(upload_to="products/logos")
    button_bg = models.CharField(max_length=128, default="color")
    bg_color = models.CharField(max_length=128, default="color")

    class Meta:
        ordering = ["id"]
        db_table = "web_Product"

    def __str__(self):
        return self.title


class Blog(models.Model):
    image = models.ImageField(upload_to="blogs/")
    title = models.CharField(max_length=255)
    content_type = models.ForeignKey("web.ContentType", on_delete= models.CASCADE)


    class Meta:
        ordering = ["id"]
        db_table = "web_Blogs"

    def __str__(self):
        return str(self.image)


class ContentType(models.Model):
    name = models.CharField(max_length=128, default="Blog Post")

    class Meta:
        ordering = ["id"]
        db_table = "web_ContentType"

    def __str__(self):
        return self.name



