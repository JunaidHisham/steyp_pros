import json

from django.http.response import HttpResponse
from django.shortcuts import render

from web.models import Feature, Subscribe, Customer, Testimonial \
    , VideoBlog, MarketingFeature ,Product, Blog


def index(request):
    customers = Customer.objects.all()
    features = Feature.objects.all()
    video_blogs = VideoBlog.objects.all()
    featured_peoples = Testimonial.objects.filter(is_featured = True)
    testimonial_posts = Testimonial.objects.filter(is_featured = False)
    marketing_features = MarketingFeature.objects.all()
    products = Product.objects.all()
    blogs = Blog.objects.all()

    # print(testimonial_posts)

    context = {
        "customers": customers,
        "features": features,
        "video_blogs": video_blogs,
        "featured_peoples": featured_peoples,
        "testimonial_posts": testimonial_posts,
        "marketing_features": marketing_features,
        "products": products,
        "blogs": blogs,

    }

    return render(request, "index.html", context)


def subscribe(request):
    email = request.POST.get("email-id")

    if not Subscribe.objects.filter(email = email).exists():
        
        Subscribe.objects.create(
            email=email
        )

        response_data = {
            "status": "success",
            "message": "Successfully Registered to our newsletter.",
            "title": "Successfully Subscribed"
        }
    else:
        response_data = {
            "status": "error",
            "message": "mail already exists.",
            "title": "Already Subscribed "
        }
        

    return HttpResponse(json.dumps(response_data), content_type="application/javascript")