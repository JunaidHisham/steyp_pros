from django.contrib import admin
from web.models import Blog, ContentType, Customer, Feature \
    , MarketingFeature, Subscribe, Testimonial, VideoBlog, Product


class SubscribeAdmin(admin.ModelAdmin):
    list_display = ["id", "email"]


admin.site.register(Subscribe, SubscribeAdmin)


class CustomerAdmin(admin.ModelAdmin):
    list_display = ["id", 'image']


admin.site.register(Customer, CustomerAdmin)


class FeatureAdmin(admin.ModelAdmin):
    list_display = ["id", "image", "testimonial_author"]


admin.site.register(Feature, FeatureAdmin)


class VideoBlogAdmin(admin.ModelAdmin):
    list_display = ["id", "image", "title"]


admin.site.register(VideoBlog, VideoBlogAdmin)


class TestimonialAdmin(admin.ModelAdmin):
    list_display = ["id", "name", "company_name"]


admin.site.register(Testimonial, TestimonialAdmin)


class MarketingFeatureAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "image"]


admin.site.register(MarketingFeature, MarketingFeatureAdmin)


class ProductAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "image"]


admin.site.register(Product, ProductAdmin)

class ContentTypeAdmin(admin.ModelAdmin):
    list_display = ["id", "name" ]


admin.site.register(ContentType, ContentTypeAdmin)

class BlogAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "image"]


admin.site.register(Blog, BlogAdmin)