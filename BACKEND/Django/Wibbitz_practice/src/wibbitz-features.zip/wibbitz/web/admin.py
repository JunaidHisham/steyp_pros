from django.contrib import admin
from web.models import Customer, Feature, Subscribe


class SubscribeAdmin(admin.ModelAdmin):
    list_display = ["id", "email"]


admin.site.register(Subscribe, SubscribeAdmin)

class CustomerAdmin(admin.ModelAdmin):
    list_display = ["id", 'image']


admin.site.register(Customer, CustomerAdmin)

class FeatureAdmin(admin.ModelAdmin):
    list_display = ["id", "image", "testimonial_author"]


admin.site.register(Feature, FeatureAdmin)