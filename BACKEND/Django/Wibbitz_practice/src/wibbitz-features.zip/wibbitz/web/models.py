from django.db import models


class Subscribe(models.Model):
    email = models.EmailField()

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.email


class Customer(models.Model):
    image = models.FileField(upload_to="customers/")

    class Meta:
        ordering = ["id"]
        db_table = "web_Customers"
        verbose_name = "Customer"

    def __str__(self):
        return str(self.image)
    

class Feature(models.Model):
    image = models.ImageField(upload_to="features/")
    icon = models.FileField(upload_to="features/icons/")
    icon_background = models.CharField(max_length=100)
    title = models.CharField(max_length=255)
    description = models.TextField()
    testimonial_des = models.TextField()
    testimonial_author = models.CharField(max_length=255)
    author_designation = models.CharField(max_length=255)
    testimonial_logo = models.FileField(upload_to="features/testimonial_logos/")

    def __str__(self):
        return str(self.image)


