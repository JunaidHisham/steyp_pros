import json

from django.http.response import HttpResponse
from django.shortcuts import render

from web.models import Feature, Subscribe, Customer


def index(request):
    customers = Customer.objects.all()
    features = Feature.objects.all()

    context = {
        "customers": customers,
        "features": features,
    }

    return render(request, "index.html", context)


def subscribe(request):
    email = request.POST.get("email-id")

    if not Subscribe.objects.filter(email = email).exists():
        
        Subscribe.objects.create(
            email=email
        )

        response_data = {
            "status": "success",
            "message": "Successfully Registered to our newsletter.",
            "title": "Successfully Subscribed"
        }
    else:
        response_data = {
            "status": "error",
            "message": "mail already exists.",
            "title": "Already Subscribed "
        }
        

    return HttpResponse(json.dumps(response_data), content_type="application/javascript")