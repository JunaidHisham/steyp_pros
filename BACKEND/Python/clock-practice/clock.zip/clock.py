from datetime import datetime
from time import strftime

while True:
    now = datetime.now()
    current_time = now.strftime("%H-%M-%S")
    current_date = now.strftime("%Y/%m/%d")
    print(current_time, current_date, end="\r")