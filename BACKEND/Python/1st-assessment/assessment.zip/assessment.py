string = 'Hello World'
slice_by = slice(5,7)
print(string[slice_by])
