list_ = [11, 5, 17, 18, 23, 50]

for i in list_:
    if i%2 == 0:
        list_.remove(i)

print(list_)
