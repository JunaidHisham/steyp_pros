value = 0
x = "kdfjgba38745634789dfg"

for num in x:
    if num.isdigit():
        value += int(num)
else:
    print(value)
